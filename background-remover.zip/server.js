import "dotenv/config";
import express from "express";
import multer from "multer";
import Replicate from "replicate";
import { writeFile, mkdir, readdir, unlink } from "fs/promises";
import { existsSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";
import sharp from "sharp";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
const PORT = 3000;

const replicate = new Replicate();

// Ensure directories exist
const UPLOAD_DIR = path.join(__dirname, "uploads");
const BASE_OUTPUT_DIR = path.join(__dirname, "output");
if (!existsSync(UPLOAD_DIR)) await mkdir(UPLOAD_DIR, { recursive: true });
if (!existsSync(BASE_OUTPUT_DIR)) await mkdir(BASE_OUTPUT_DIR, { recursive: true });

// Get next run directory: output/run1, output/run2, etc.
async function getNextRunDir() {
  const existing = await readdir(BASE_OUTPUT_DIR);
  const runNums = existing
    .filter((d) => d.startsWith("run"))
    .map((d) => parseInt(d.replace("run", ""), 10))
    .filter((n) => !isNaN(n));
  const next = runNums.length > 0 ? Math.max(...runNums) + 1 : 1;
  const runDir = path.join(BASE_OUTPUT_DIR, `run${next}`);
  await mkdir(runDir, { recursive: true });
  return runDir;
}

// Multer config for file uploads
const storage = multer.diskStorage({
  destination: UPLOAD_DIR,
  filename: (_req, file, cb) => {
    // Keep original name but ensure uniqueness
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e4);
    const ext = path.extname(file.originalname);
    const name = path.basename(file.originalname, ext);
    cb(null, `${name}-${uniqueSuffix}${ext}`);
  },
});

const upload = multer({
  storage,
  fileFilter: (_req, file, cb) => {
    const allowed = [".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tiff"];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowed.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error(`File type ${ext} not supported`));
    }
  },
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB per file
});

// Track processing jobs
const jobs = new Map();

const ALLOWED_EXTS = [".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tiff"];

app.use(express.json());

// Serve static frontend
app.use(express.static(path.join(__dirname, "public")));

// Serve output files
app.use("/output", express.static(BASE_OUTPUT_DIR));

// Upload endpoint
app.post("/api/upload", upload.array("images", 100), async (req, res) => {
  if (!req.files || req.files.length === 0) {
    return res.status(400).json({ error: "No files uploaded" });
  }

  const concurrency = Math.min(Math.max(parseInt(req.body.concurrency, 10) || 3, 1), 10);
  const targetWidth = parseInt(req.body.targetWidth, 10) || 0;
  const autoCenter = req.body.autoCenter === "1";
  const namePrefix = req.body.namePrefix || "image";
  let userRotations = [];
  try { userRotations = JSON.parse(req.body.rotations || "[]"); } catch {}

  const jobId = Date.now().toString(36) + Math.random().toString(36).slice(2);
  const fileList = req.files.map((f, idx) => ({
    uploadName: f.filename,
    originalName: f.originalname,
    rotation: userRotations[idx] || 0,
    status: "pending",
    output: null,
    error: null,
  }));

  const runDir = await getNextRunDir();
  const runName = path.basename(runDir);

  jobs.set(jobId, {
    total: fileList.length,
    completed: 0,
    failed: 0,
    files: fileList,
    done: false,
    runDir,
    runName,
    concurrency,
    targetWidth,
    autoCenter,
    namePrefix,
    nameCounter: 0,
  });

  // Process in background
  processJob(jobId).catch(console.error);

  return res.json({ jobId, total: fileList.length });
});

// Job status endpoint
app.get("/api/status/:jobId", (req, res) => {
  const job = jobs.get(req.params.jobId);
  if (!job) return res.status(404).json({ error: "Job not found" });
  return res.json(job);
});

// Scan a local folder for images
app.post("/api/scan-folder", async (req, res) => {
  const folderPath = req.body.path;
  if (!folderPath || !existsSync(folderPath)) {
    return res.status(400).json({ error: "Folder not found" });
  }

  const allFiles = await readdir(folderPath);
  const imageFiles = allFiles.filter((f) => {
    const ext = path.extname(f).toLowerCase();
    return ALLOWED_EXTS.includes(ext) && !f.startsWith(".");
  });

  if (imageFiles.length === 0) {
    return res.status(400).json({ error: "No image files found in folder" });
  }

  // Return first 20 as sample paths for preview
  const samples = imageFiles.slice(0, 20).map((f) => path.join(folderPath, f));

  return res.json({ path: folderPath, count: imageFiles.length, files: imageFiles, samples });
});

// Serve a thumbnail preview of a local file
app.get("/api/preview", async (req, res) => {
  const filePath = req.query.path;
  if (!filePath || !existsSync(filePath)) {
    return res.status(404).send("Not found");
  }

  try {
    const thumbnail = await sharp(filePath)
      .rotate()
      .resize(400, 300, { fit: "inside", withoutEnlargement: true })
      .jpeg({ quality: 60 })
      .toBuffer();

    res.set("Content-Type", "image/jpeg");
    res.set("Cache-Control", "private, max-age=300");
    return res.send(thumbnail);
  } catch {
    return res.status(500).send("Failed to generate preview");
  }
});

// Process images from a local folder (no upload needed)
app.post("/api/process-folder", async (req, res) => {
  const { folderPath, concurrency: concStr, targetWidth: twStr, autoCenter, namePrefix } = req.body;

  if (!folderPath || !existsSync(folderPath)) {
    return res.status(400).json({ error: "Folder not found" });
  }

  const allFiles = await readdir(folderPath);
  const imageFiles = allFiles.filter((f) => {
    const ext = path.extname(f).toLowerCase();
    return ALLOWED_EXTS.includes(ext) && !f.startsWith(".");
  });

  if (imageFiles.length === 0) {
    return res.status(400).json({ error: "No image files found" });
  }

  const concurrency = Math.min(Math.max(parseInt(concStr, 10) || 3, 1), 10);
  const targetWidth = parseInt(twStr, 10) || 0;

  const jobId = Date.now().toString(36) + Math.random().toString(36).slice(2);
  const fileList = imageFiles.map((f) => ({
    sourcePath: path.join(folderPath, f),
    originalName: f,
    rotation: 0,
    status: "pending",
    output: null,
    error: null,
  }));

  const runDir = await getNextRunDir();
  const runName = path.basename(runDir);

  jobs.set(jobId, {
    total: fileList.length,
    completed: 0,
    failed: 0,
    files: fileList,
    done: false,
    runDir,
    runName,
    concurrency,
    targetWidth,
    autoCenter: autoCenter === "1",
    namePrefix: namePrefix || "image",
    nameCounter: 0,
    folderMode: true,
  });

  processJob(jobId).catch(console.error);

  return res.json({ jobId, total: fileList.length });
});

// Clear uploads and jobs (output/runX folders are kept)
app.post("/api/clear", async (_req, res) => {
  const uploads = await readdir(UPLOAD_DIR);
  for (const file of uploads) {
    await unlink(path.join(UPLOAD_DIR, file));
  }
  jobs.clear();
  return res.json({ ok: true });
});

async function processJob(jobId) {
  const job = jobs.get(jobId);
  if (!job) return;

  const concurrency = job.concurrency;
  let index = 0;

  async function processNext() {
    if (index >= job.files.length) return;
    const i = index++;
    const file = job.files[i];

    try {
      file.status = "processing";

      // Read the file, auto-rotate based on EXIF + user rotation, convert to JPEG for smaller payload
      const filePath = job.folderMode ? file.sourcePath : path.join(UPLOAD_DIR, file.uploadName);
      const metadata = await sharp(filePath).metadata();
      let pipeline = sharp(filePath).rotate(); // auto-rotate based on EXIF

      // Apply user-specified rotation (0, 90, 180, 270)
      if (file.rotation) {
        pipeline = sharp(await pipeline.toBuffer()).rotate(file.rotation);
      }

      // Downscale if too large (Replicate has ~10MB payload limit for base64)
      const maxDim = 4096;
      if ((metadata.width || 0) > maxDim || (metadata.height || 0) > maxDim) {
        pipeline = pipeline.resize(maxDim, maxDim, { fit: "inside", withoutEnlargement: true });
      }

      const rotatedBuffer = await pipeline.jpeg({ quality: 90 }).toBuffer();
      const dataUri = `data:image/jpeg;base64,${rotatedBuffer.toString("base64")}`;

      const output = await replicate.run(
        "851-labs/background-remover:a029dff38972b5fda4ec5d75d7d1cd25aeff621d2cf4946a41055d7db66b80bc",
        { input: { image: dataUri } }
      );

      // Save output PNG with sequential naming: prefix-1.png, prefix-2.png, ...
      job.nameCounter++;
      const outputName = `${job.namePrefix}-${job.nameCounter}.png`;
      const finalPath = path.join(job.runDir, outputName);

      // Fetch the output image from Replicate's URL
      const outputUrl = typeof output === "string" ? output : output.url();
      const response = await fetch(outputUrl);
      let outputBuffer = Buffer.from(await response.arrayBuffer());

      // Auto-center: trim transparent space, then re-pad with 5% padding
      if (job.autoCenter) {
        const trimmed = await sharp(outputBuffer)
          .trim()
          .toBuffer({ resolveWithObject: true });

        const { width, height } = trimmed.info;
        const padSize = Math.round(Math.max(width, height) * 0.05);

        outputBuffer = await sharp(trimmed.data)
          .extend({
            top: padSize,
            bottom: padSize,
            left: padSize,
            right: padSize,
            background: { r: 0, g: 0, b: 0, alpha: 0 },
          })
          .png()
          .toBuffer();
      }

      // Resize to target width if specified
      if (job.targetWidth > 0) {
        const resized = await sharp(outputBuffer)
          .resize({ width: job.targetWidth })
          .png()
          .toBuffer();
        await writeFile(finalPath, resized);
      } else {
        await writeFile(finalPath, outputBuffer);
      }

      file.status = "done";
      file.output = `${job.runName}/${path.basename(finalPath)}`;
      job.completed++;
    } catch (err) {
      file.status = "error";
      file.error = err.message || "Unknown error";
      job.failed++;
      console.error(`Error processing ${file.originalName}:`, err.message);
    }

    // Process next file
    await processNext();
  }

  // Start concurrent workers
  const workers = [];
  for (let i = 0; i < Math.min(concurrency, job.files.length); i++) {
    workers.push(processNext());
  }
  await Promise.all(workers);

  job.done = true;

  // Clean up uploads after processing (skip for folder mode — those are the user's files)
  if (!job.folderMode) {
    for (const file of job.files) {
      const uploadPath = path.join(UPLOAD_DIR, file.uploadName);
      if (existsSync(uploadPath)) {
        await unlink(uploadPath).catch(() => {});
      }
    }
  }
}

app.listen(PORT, () => {
  console.log(`\n  Background Remover running at http://localhost:${PORT}\n`);
  console.log(`  Output folder: ${BASE_OUTPUT_DIR}\n`);
});
