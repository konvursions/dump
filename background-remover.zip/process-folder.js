import "dotenv/config";
import Replicate from "replicate";
import sharp from "sharp";
import { writeFile, mkdir, readdir } from "fs/promises";
import { existsSync } from "fs";
import path from "path";
import readline from "readline";

const ALLOWED_EXTS = [".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tiff"];

// ── Interactive prompt helpers ──────────────────────────────────────

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise((resolve) => rl.question(q, resolve));

async function askRequired(question) {
  let answer = "";
  while (!answer.trim()) {
    answer = await ask(question);
  }
  return answer.trim();
}

async function askOptional(question, fallback) {
  const answer = (await ask(question)).trim();
  return answer || fallback;
}

async function askYesNo(question, defaultYes = false) {
  const hint = defaultYes ? "[Y/n]" : "[y/N]";
  const answer = (await ask(`${question} ${hint} `)).trim().toLowerCase();
  if (!answer) return defaultYes;
  return answer.startsWith("y");
}

// ── Main ────────────────────────────────────────────────────────────

console.log("\n  ── Background Remover ──\n");

// Step 1: Input folder
const inputDir = await askRequired("  Input folder path: ");

if (!existsSync(inputDir)) {
  console.error(`\n  Folder not found: ${inputDir}\n`);
  process.exit(1);
}

// Scan for images
const allFiles = await readdir(inputDir);
const imageFiles = allFiles.filter((f) => {
  const ext = path.extname(f).toLowerCase();
  return ALLOWED_EXTS.includes(ext) && !f.startsWith(".");
});

if (imageFiles.length === 0) {
  console.error(`\n  No image files found in ${inputDir}\n`);
  process.exit(1);
}

console.log(`\n  Found ${imageFiles.length} images\n`);

// Step 2: Concurrency
const concurrencyStr = await askOptional("  Parallel processing (default 3): ", "3");
const concurrency = Math.min(Math.max(parseInt(concurrencyStr, 10) || 3, 1), 10);

// Step 3: Target width
const widthStr = await askOptional("  Target width in px (leave blank to keep original): ", "");
const targetWidth = parseInt(widthStr, 10) || 0;

// If target width set, check for upscaling
if (targetWidth > 0) {
  let upscaleCount = 0;
  let maxPct = 0;

  for (const filename of imageFiles) {
    try {
      const meta = await sharp(path.join(inputDir, filename)).metadata();
      const w = meta.width || 0;
      if (w > 0 && w < targetWidth) {
        upscaleCount++;
        const pct = Math.round(((targetWidth - w) / w) * 100);
        if (pct > maxPct) maxPct = pct;
      }
    } catch {
      // skip unreadable files
    }
  }

  if (upscaleCount > 0) {
    console.log(`\n  Warning: ${upscaleCount} image${upscaleCount > 1 ? "s are" : " is"} smaller than ${targetWidth}px (up to ${maxPct}% upscale). These may appear blurry.`);
  }
}

// Step 4: Auto-center
const autoCenter = await askYesNo("\n  Auto-center (trim whitespace + 5% padding)?");

// Step 5: Name prefix
const namePrefix = await askOptional("\n  Output name prefix (default: image): ", "image");

// Step 6: Confirm
console.log("\n  ── Summary ──");
console.log(`  Images:      ${imageFiles.length}`);
console.log(`  Parallel:    ${concurrency}`);
console.log(`  Width:       ${targetWidth > 0 ? targetWidth + "px" : "original"}`);
console.log(`  Auto-center: ${autoCenter ? "yes" : "no"}`);
console.log(`  Naming:      ${namePrefix}-1.png, ${namePrefix}-2.png, ...`);

const proceed = await askYesNo("\n  Start processing?", true);
if (!proceed) {
  console.log("\n  Cancelled.\n");
  rl.close();
  process.exit(0);
}

rl.close();

// ── Setup output ────────────────────────────────────────────────────

const baseOutputDir = path.join(path.dirname(import.meta.filename), "output");
if (!existsSync(baseOutputDir)) await mkdir(baseOutputDir, { recursive: true });
const existing = await readdir(baseOutputDir);
const runNums = existing
  .filter((d) => d.startsWith("run"))
  .map((d) => parseInt(d.replace("run", ""), 10))
  .filter((n) => !isNaN(n));
const nextRun = runNums.length > 0 ? Math.max(...runNums) + 1 : 1;
const outputDir = path.join(baseOutputDir, `run${nextRun}`);
await mkdir(outputDir, { recursive: true });

console.log(`\n  Output: ${outputDir}`);
console.log(`  Processing ${concurrency} at a time...\n`);

// ── Process ─────────────────────────────────────────────────────────

const replicate = new Replicate();
let completed = 0;
let failed = 0;
let index = 0;
let nameCounter = 0;

async function processNext() {
  if (index >= imageFiles.length) return;
  const i = index++;
  const filename = imageFiles[i];
  const filePath = path.join(inputDir, filename);

  try {
    // Auto-rotate based on EXIF, downscale if too large for Replicate
    const metadata = await sharp(filePath).metadata();
    let pipeline = sharp(filePath).rotate();

    const maxDim = 4096;
    if ((metadata.width || 0) > maxDim || (metadata.height || 0) > maxDim) {
      pipeline = pipeline.resize(maxDim, maxDim, { fit: "inside", withoutEnlargement: true });
    }

    const rotatedBuffer = await pipeline.jpeg({ quality: 90 }).toBuffer();
    const dataUri = `data:image/jpeg;base64,${rotatedBuffer.toString("base64")}`;

    const output = await replicate.run(
      "851-labs/background-remover:a029dff38972b5fda4ec5d75d7d1cd25aeff621d2cf4946a41055d7db66b80bc",
      { input: { image: dataUri } }
    );

    // Fetch the output image from Replicate's URL
    const outputUrl = typeof output === "string" ? output : output.url();
    const response = await fetch(outputUrl);
    let outputBuffer = Buffer.from(await response.arrayBuffer());

    // Auto-center: trim transparent space, then re-pad with 5% padding
    if (autoCenter) {
      const trimmed = await sharp(outputBuffer)
        .trim()
        .toBuffer({ resolveWithObject: true });

      const { width, height } = trimmed.info;
      const padSize = Math.round(Math.max(width, height) * 0.05);

      outputBuffer = await sharp(trimmed.data)
        .extend({
          top: padSize,
          bottom: padSize,
          left: padSize,
          right: padSize,
          background: { r: 0, g: 0, b: 0, alpha: 0 },
        })
        .png()
        .toBuffer();
    }

    // Resize to target width if specified
    if (targetWidth > 0) {
      outputBuffer = await sharp(outputBuffer)
        .resize({ width: targetWidth })
        .png()
        .toBuffer();
    }

    // Save with sequential naming: prefix-1.png, prefix-2.png, ...
    nameCounter++;
    const outputName = `${namePrefix}-${nameCounter}.png`;
    const finalPath = path.join(outputDir, outputName);

    await writeFile(finalPath, outputBuffer);
    completed++;
    console.log(`  [${completed + failed}/${imageFiles.length}] done  ${filename}`);
  } catch (err) {
    failed++;
    console.error(`  [${completed + failed}/${imageFiles.length}] fail  ${filename} — ${err.message}`);
  }

  await processNext();
}

// Start concurrent workers
const workers = [];
for (let i = 0; i < Math.min(concurrency, imageFiles.length); i++) {
  workers.push(processNext());
}
await Promise.all(workers);

console.log(`\n  Done! ${completed} succeeded, ${failed} failed.`);
console.log(`  Output saved to: ${outputDir}\n`);
